import 'package:upi_pay/upi_pay.dart';

/// UPI payment handler using the `upi_pay` package (v1.1.0).
/// This file provides a small wrapper around the package with defensive
/// mapping so it works across platform/version differences.
class UpiPaymentHandler {
  /// List installed UPI apps. Returns simple maps with keys:
  /// - packageName
  /// - name
  /// - icon (string if available)
  Future<List<Map<String, String>>> getInstalledApps() async {
    try {
      final upi = UpiPay();
      // Use dynamic to avoid tight static coupling to minor API changes
      final apps = await (upi as dynamic).getInstalledUpiApplications();
      if (apps == null) return [];

      final List<Map<String, String>> list = [];
      for (final a in (apps as List)) {
        final d = a as dynamic;
        final packageName = (d.packageName?.toString() ?? d.upiApplication?.toString() ?? '');
        final name = (d.name?.toString() ?? d.upiApplication?.toString() ?? packageName);
        final icon = (d.icon?.toString() ?? '');
        list.add({'packageName': packageName, 'name': name, 'icon': icon});
      }
      return list;
    } catch (e) {
      // Defensive: return empty list on any failure
      return [];
    }
  }

  /// Initiate a UPI payment.
  ///
  /// - amount: decimal amount as double (will be formatted to 2 decimals)
  /// - receiverUpi: receiver UPI id (example: merchant@bank)
  /// - receiverName: display name for receiver
  /// - note: optional transaction note
  /// - appPackage: optional packageName of UPI app to launch. If null, the
  ///   package may present a chooser.
  Future<Map<String, dynamic>> initiatePayment({
    required double amount,
    required String receiverUpi,
    required String receiverName,
    String? note,
    String? appPackage, required String upiId, required String merchantName, required String transactionNote, required String upiApp,
  }) async {
    final transactionRef = 'TXN${DateTime.now().millisecondsSinceEpoch}';
    final amountStr = amount.toStringAsFixed(2);

    try {
      final upi = UpiPay() as dynamic;
      final response = await upi.initiateTransaction(
        amount: amountStr,
        app: appPackage,
        receiverUpiAddress: receiverUpi,
        receiverName: receiverName,
        transactionRef: transactionRef,
        transactionNote: note ?? 'Payment',
      );

      return _processResponse(response, transactionRef);
    } catch (e) {
      return {
        'status': 'FAILED',
        'message': 'Failed to start UPI transaction: $e',
        'transactionRef': transactionRef,
      };
    }
  }

  Map<String, dynamic> _processResponse(dynamic response, String transactionRef) {
    try {
      if (response == null) {
        return {
          'status': 'CANCELLED',
          'transactionRef': transactionRef,
          'message': 'No response (maybe cancelled by user)',
          'raw': response,
        };
      }

      final dyn = response as dynamic;

      // Common candidates for status fields across versions
      final statusCandidates = [
        dyn.status,
        dyn.transactionStatus,
        dyn.statusMessage,
        dyn.rawResponse,
      ];

      final statusStr = statusCandidates
          .where((s) => s != null)
          .map((s) => s.toString().toLowerCase())
          .join(' ');

      if (statusStr.contains('success')) {
        return {
          'status': 'SUCCESS',
          'transactionRef': transactionRef,
          'transactionId': dyn.txnId ?? dyn.transactionId ?? dyn.txn_id,
          'approvalRefNo': dyn.approvalRefNo ?? dyn.responseCode,
          'raw': response,
          'message': 'Payment successful',
        };
      }

      if (statusStr.contains('failure') || statusStr.contains('failed')) {
        return {
          'status': 'FAILED',
          'transactionRef': transactionRef,
          'message': dyn.rawResponse ?? dyn.errorMessage ?? 'Payment failed',
          'raw': response,
        };
      }

      // default: treat as cancelled / not completed
      return {
        'status': 'CANCELLED',
        'transactionRef': transactionRef,
        'message': 'Payment cancelled or not completed',
        'raw': response,
      };
    } catch (e) {
      return {
        'status': 'FAILED',
        'transactionRef': transactionRef,
        'message': 'Error processing response: $e',
        'raw': response,
      };
    }
  }

  /// Lightweight UPI id validation
  bool isValidUpiId(String upiId) {
    final upiRegex = RegExp(r'^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64} ');
    // The regex above intentionally allows typical UPI ids; depending on
    // your app locale you may relax or tighten this.
    return upiRegex.hasMatch(upiId.trim());
  }
}

/*
Example usage:

final handler = UpiPaymentHandler();
final apps = await handler.getInstalledApps();
// Show apps to user and let them pick one (apps[i]['packageName'])

final result = await handler.initiatePayment(
  amount: 100.0,
  receiverUpi: 'merchant@bank',
  receiverName: 'Merchant Name',
  note: 'Order #123',
  appPackage: apps.isNotEmpty ? apps.first['packageName'] : null,
);

print(result);
*/
